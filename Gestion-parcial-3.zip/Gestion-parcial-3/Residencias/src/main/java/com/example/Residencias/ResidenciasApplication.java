package com.example.Residencias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResidenciasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResidenciasApplication.class, args);
	}

}
